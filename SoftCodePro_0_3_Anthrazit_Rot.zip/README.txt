Soft Code Pro 0.3: index.html im Hauptverzeichnis des bestehenden GitHub-Pages-Repositories ersetzen. Fahrzeugdaten aus Version 0.2 bleiben im gleichen Browser erhalten (localStorage softcodepro-v02). Adapterseite ist eine Prüfliste, keine echte Bluetooth-Verbindung. Keine Schreibfunktionen.

Design: Anthrazit / Rot. Funktional identisch zur Version 0.3.
